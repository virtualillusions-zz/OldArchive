There is a blender-script that do this for you. Have a look here:

http://www.jmonkeyengine.com/forum/index.php?topic=14026.0

- Download the file
- rename it so it only have the .py extension. 
- Place it where you placed the ogre-export-script in the blender-script-dir. 
- Restart blender
- select mesh
- change to weight-paint
- in the 3d-view menu -> paint -> Normalise Vertex Group Weights for Ogre

That will take the 4 most influcing bones for each vertex and normalizes its weights and set the other influences to zero.

That will remove at least the "Vertex with more thant 4 bones.." warning.