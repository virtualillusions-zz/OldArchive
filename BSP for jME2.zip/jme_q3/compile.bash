#!/bin/bash

jme=/opt/jmonkeyengine
lwjgl=/opt/lwjgl-2.0rc1

CP=.
CP=$CP:$lwjgl/jar/lwjgl.jar
CP=$CP:$lwjgl/jar/lwjgl_util.jar
CP=$CP:$lwjgl/lwjgl_util_applet.jar
CP=$CP:$jme/target/jme.jar
CP=$CP:$jme/target/jme-awt.jar
CP=$CP:$jme/target/jme-audio.jar
CP=$CP:$jme/target/jme-effects.jar
CP=$CP:$jme/target/jme-model.jar
CP=$CP:$jme/target/jme-terrain.jar
CP=$CP:$jme/target/jme-scene.jar
CP=$CP:$jme/target/jme-font.jar
CP=$CP:$jme/target/jme-gamestates.jar
CP=$CP:$jme/target/jmetest.jar

#javac -cp $CP trb/jme/quake3/Quake3Loader.java 
javac -cp $CP -sourcepath trb trb/jme/quake3/JMEQuake3Renderer.java
