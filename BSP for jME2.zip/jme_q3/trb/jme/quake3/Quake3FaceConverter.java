package trb.jme.quake3;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import com.jme.image.Texture;
import com.jme.renderer.Renderer;
import com.jme.scene.TexCoords;
import com.jme.scene.TriMesh;
import com.jme.scene.Spatial.CullHint;
import com.jme.scene.state.BlendState;
import com.jme.scene.state.TextureState;
import com.jme.system.DisplaySystem;
import com.jme.util.TextureManager;
import com.jme.util.geom.BufferUtils;

import trb.jme.imaging.DirectBufferedImage;
import trb.jme.imaging.TextureLoader;
import trb.jme.quake3.lumps.tBSPFace;
import trb.jme.quake3.lumps.tBSPTextures;
import trb.jme.quake3.lumps.tBSPVertex;

public class Quake3FaceConverter {

    /** Loads the Q3 file */
    private Quake3Loader loader;
    /** The lightmap textures */
    private Texture lightTextures[];
    /** The the base textures */
    private Texture textures[];
    
    private BlendState lightAlphaState;

    /** The default texture is used if the real file is not found */
    private static Texture defTexture;
    private static Texture environment = null;
    
    /** The total number of triangles */
    public int triangleCnt = 0;
    
	private int count = 0;

	
    /**
     * 
     * @param loader
     */
	public Quake3FaceConverter(Quake3Loader loader){
		this.loader=loader;
        triangleCnt = 0;
	}

	
    /**
     * Converts a BSP face definition into a Shape3D
     */
    public TriMesh convert(tBSPFace face, DisplaySystem display) {
        TriMesh triMesh = null;
        switch (face.type) {
        	case 1:
        	case 3:
        		// either polygon or model
        		triMesh = convertToIndexed(face);
        		break;
        	case 2:
        		// bezier patch
        		triMesh = convertSurfacePatch(face);
        		break;
        	case 4:
        		triMesh = convertToBillboard(face);
//        		System.out.println("BILLBOARD.");
        		return null;
        	default:
        		return null;
        }

        triMesh.setName("tm: "+(++count));

        if (face.textureID<0) {
            System.out.println("no texture, skipping");
            return null;
        }

        tBSPTextures tt = loader.textures[face.textureID];
        triMesh.setModelBound(new com.jme.bounding.BoundingBox()); 
        triMesh.updateModelBound();

        
        System.out.println("" + count + 
				":S=" + Quake3Loader.printHEX(tt.surfaceFlags) +
				":C=" + Quake3Loader.printHEX(tt.contentFlags) +
        		":T=" + face.type + 
        		":Name=" + tt.name );
        
        
        TextureState textureState=null;
		if (face.lightmapID < 0 ){
			textureState = display.getRenderer().createTextureState();
			Texture t = textures[face.textureID];
			textureState.setTexture(t, 0);
			triMesh.setRenderState(textureState);
			
			// Here deal with glowing things and transparent stuff...unaffected by the lightmap.
        	lightAlphaState = display.getRenderer().createBlendState();
        	lightAlphaState.setBlendEnabled(true);
        	lightAlphaState.setSourceFunction(BlendState.SourceFunction.SourceAlpha);
        	lightAlphaState.setDestinationFunction(BlendState.DestinationFunction.OneMinusSourceColor);
        	lightAlphaState.setTestEnabled(true);
        	lightAlphaState.setTestFunction(BlendState.TestFunction.GreaterThan);
        	lightAlphaState.setEnabled(true);
			triMesh.setRenderState(lightAlphaState);

			triMesh.updateRenderState();
			triMesh.setRenderQueueMode(Renderer.QUEUE_OPAQUE);
		}
		else
		{
			textureState = display.getRenderer().createTextureState();
			Texture t = textures[face.textureID];
        	textureState.setTexture(t, 0);
			triMesh.setRenderState(textureState);

			Texture lt = lightTextures[face.lightmapID];
			lt.setApply(Texture.ApplyMode.Combine);							//.AM_COMBINE);
			textureState.setTexture(lt, 1);
		}

		
		if( (tt.surfaceFlags & tBSPTextures.SURF_SKY) > 0) {
			Texture env = getEnvironmentTexture();
			env.setApply(Texture.ApplyMode.Modulate);							//.AM_COMBINE);
			textureState.setTexture(env, 2);
	        env.setEnvironmentalMapMode(Texture.EnvironmentalMapMode.ReflectionMap );
	        triMesh.updateRenderState();
		}

		return triMesh;
    }


    

    /**
     * Creates the indexed geometry array for the BSP face.  The lightmap tex coords are stored in
     * unit 1, the regular tex coords are stored in unit 2
     * @param face the bsp face to convert 
     * @return a IndexTriangleArray containing the geometry of the face
     */
    private TriMesh convertToIndexed(tBSPFace face) {
    	triangleCnt += face.numMeshVerts/3;
    	
    	FloatBuffer coordinates = BufferUtils.createFloatBuffer(face.numOfVerts*3);
    	FloatBuffer texCoords = BufferUtils.createFloatBuffer(face.numOfVerts*2);
    	FloatBuffer lightTexCoords = BufferUtils.createFloatBuffer(face.numOfVerts*2);
        for (int i = 0; i < face.numOfVerts; i++) {
            int j = face.vertexIndex + i;
        	coordinates.put(loader.vertices[j].position.x * loader.worldScale);
        	coordinates.put(loader.vertices[j].position.z * loader.worldScale);
        	coordinates.put(-loader.vertices[j].position.y * loader.worldScale);
        	texCoords.put(loader.vertices[j].texCoord.x);
        	texCoords.put(loader.vertices[j].texCoord.y);
        	lightTexCoords.put(loader.vertices[j].lightTexCoord.x);
        	lightTexCoords.put(loader.vertices[j].lightTexCoord.y);
        }
        coordinates.rewind();
        texCoords.rewind();
        lightTexCoords.rewind();

        int index[] = new int[face.numMeshVerts];
        System.arraycopy( loader.meshVertices, face.meshVertIndex, index, 0, face.numMeshVerts );
        IntBuffer indices = BufferUtils.createIntBuffer(index.length);
        indices.put(index);
        indices.rewind();

        TriMesh triMesh = new TriMesh( "", coordinates, null, null, null, indices );
        triMesh.setTextureCoords( new TexCoords(texCoords,2), 0 );
        triMesh.setTextureCoords( new TexCoords(lightTexCoords,2), 1 );
        return triMesh;
    }



    private TriMesh convertToBillboard(tBSPFace face) {
    	triangleCnt += face.numMeshVerts/3;
    	FloatBuffer coordinates = BufferUtils.createFloatBuffer(face.numOfVerts*3);
    	FloatBuffer texCoords = BufferUtils.createFloatBuffer(face.numOfVerts*2);
    	FloatBuffer lightTexCoords = BufferUtils.createFloatBuffer(face.numOfVerts*2);
        for (int i = 0; i < face.numOfVerts; i++) {
            int j = face.vertexIndex + i;
        	coordinates.put(loader.vertices[j].position.x * loader.worldScale);
        	coordinates.put(loader.vertices[j].position.z * loader.worldScale);
        	coordinates.put(-loader.vertices[j].position.y * loader.worldScale);
        	texCoords.put(loader.vertices[j].texCoord.x);
        	texCoords.put(loader.vertices[j].texCoord.y);
        	lightTexCoords.put(loader.vertices[j].lightTexCoord.x);
        	lightTexCoords.put(loader.vertices[j].lightTexCoord.y);
        }
        coordinates.rewind();
        texCoords.rewind();
        lightTexCoords.rewind();

        int index[] = new int[face.numMeshVerts];
        System.arraycopy( loader.meshVertices, face.meshVertIndex, index, 0, face.numMeshVerts );
        IntBuffer indices = BufferUtils.createIntBuffer(index.length);
        indices.put(index);
        indices.rewind();

        TriMesh triMesh = new TriMesh( "", coordinates, null, null, null, indices );
        triMesh.setTextureCoords( new TexCoords(texCoords,2), 0 );
        triMesh.setTextureCoords( new TexCoords(lightTexCoords,2), 1 );
    	triMesh.setCullHint(CullHint.Never);
		triMesh.setRenderQueueMode(Renderer.QUEUE_TRANSPARENT);
        return triMesh;
    }




    /**
     * Creates the indexed geometry array for the BSP curved surface face.  The
     * lightmap tex coords are stored in unit 1, the regular tex coords are stored in unit 2
     * @param face the bsp face to convert 
     * @return a IndexTriangleArray containing the geometry of the face
     */
    private TriMesh convertSurfacePatch(tBSPFace face) {

    	tBSPVertex control[] = new tBSPVertex[face.numOfVerts];
        for (int i=0;i<face.numOfVerts;i++){
            control[i] = loader.vertices[face.vertexIndex+i];
        }
        PatchSurface ps = new PatchSurface(control,face.numOfVerts,face.size[0],face.size[1]);

    	FloatBuffer coordinates = BufferUtils.createFloatBuffer(ps.mPoints.length*3);
    	FloatBuffer texCoords = BufferUtils.createFloatBuffer(ps.mPoints.length*2);
    	FloatBuffer lightTexCoords = BufferUtils.createFloatBuffer(ps.mPoints.length*2);
        for (int i = 0; i < ps.mPoints.length; i++) {
            coordinates.put(ps.mPoints[i].position.x * loader.worldScale);
        	coordinates.put(ps.mPoints[i].position.z * loader.worldScale);
        	coordinates.put(-ps.mPoints[i].position.y * loader.worldScale);
        	texCoords.put(ps.mPoints[i].texCoord.x);
        	texCoords.put(ps.mPoints[i].texCoord.y);
        	lightTexCoords.put(ps.mPoints[i].lightTexCoord.x);
        	lightTexCoords.put(ps.mPoints[i].lightTexCoord.y);
        }
        coordinates.rewind();
        texCoords.rewind();
        lightTexCoords.rewind();
    	
        IntBuffer indices = BufferUtils.createIntBuffer(ps.mIndices.length);
        indices.put(ps.mIndices);
        indices.rewind();
    	
        TriMesh triMesh = new TriMesh( "", coordinates, null, null, null, indices );
        triMesh.setTextureCoords( new TexCoords(texCoords,2), 0 );
        triMesh.setTextureCoords( new TexCoords(lightTexCoords,2), 1 );

//    	triMesh.setCullHint(CullHint.Dynamic);
//        triMesh.setRenderQueueMode(Renderer.QUEUE_OPAQUE);
        return triMesh;
    }

    
    /**
	 * Builds image components for all the lightmaps.
	 */
    public void convertLightMaps() {
        lightTextures = new Texture[loader.lightmaps.length];
        for (int i = 0; i < loader.lightmaps.length; i++) {
            changeGamma(loader.lightmaps[i],2.2f);
            lightTextures[i] = TextureManager.loadTexture(
            		loader.lightmaps[i],
					Texture.MinificationFilter.Trilinear,				//.MM_LINEAR_LINEAR,
					Texture.MagnificationFilter.Bilinear,				//.FM_LINEAR,
					false
					);
            lightTextures[i].setWrap(Texture.WrapMode.BorderClamp);		//.WM_WRAP_S_WRAP_T);
        }
    }

    
    /**
	 * Builds image components for all the lightmaps.
	 */
    public void convertTextures() {
		textures = new Texture[loader.textures.length];
        System.err.println("************** TEXTURES: "+textures.length);

        for (int i = 0; i < loader.textures.length; i++) {
        	String t = loader.textures[i].name;
			Texture tx = loadTexture(t);
			textures[i] = tx;
		}
	}

    
    /**
     * Load a texture and return it.
     * @param filename
     * @return
     */
    static Texture loadTexture(String filename){
		String fullpath = TextureLoader.getInstance().findImageFile(filename + ".jpg");
		if (fullpath == null) {
			fullpath = TextureLoader.getInstance().findImageFile(filename + ".tga");
		}
		// If its still null, look in the current directory
		if( fullpath == null ) {
			filename = filename.substring(filename.lastIndexOf("/") + 1);
			fullpath = TextureLoader.getInstance().findImageFile(filename + ".jpg");
			if (fullpath == null) {
				fullpath = TextureLoader.getInstance().findImageFile(filename + ".tga");
			}
    	}

		Texture tx = null;
		if (fullpath != null) {
			tx = TextureManager.loadTexture(
					fullpath,
					Texture.MinificationFilter.Trilinear,	//.MM_LINEAR_LINEAR,
					Texture.MagnificationFilter.Bilinear,	//.FM_LINEAR,
					1.0f,
					false
			);
			tx.setWrap(Texture.WrapMode.Repeat);			//.WM_CLAMP_S_CLAMP_T);
		} else {
			tx = getDefaultTexture();
		}	
		return tx;
    }
    
    /**
     * Gets a reference to the default texture
     */
    static private Texture getDefaultTexture() {
        if (defTexture != null) {
        	return defTexture;
        }
        
        BufferedImage im = DirectBufferedImage.getDirectImageRGB(256, 256);
        Graphics g = im.getGraphics();
        g.setColor(Color.red);
        g.fillRect(0, 0, 256, 256);
        g.dispose();

        defTexture = TextureManager.loadTexture(
        		im,
				Texture.MinificationFilter.BilinearNoMipMaps,	//.MM_LINEAR,
				Texture.MagnificationFilter.Bilinear,			//.FM_LINEAR,
				false
				);
        return defTexture;
    }


    

    static private Texture getEnvironmentTexture() {
        if (environment != null) {
        	return environment;
        }

        BufferedImage im = DirectBufferedImage.getDirectImageRGB(256, 256);
        Graphics g = im.getGraphics();
        g.setColor(Color.GREEN);
        g.fillRect(0, 0, 256, 256);
        g.dispose();

        String path = "D:/games/quake3/unpacked/textures/skies/intelredclouds.jpg";
        environment = TextureManager.loadTexture(
        		path,
        		Texture.MinificationFilter.Trilinear,
        		Texture.MagnificationFilter.Bilinear);
        environment.setEnvironmentalMapMode(Texture.EnvironmentalMapMode.SphereMap);
        environment.setWrap(Texture.WrapMode.Repeat);
        return environment;
    }

    
    
    
    /**
     * This function was taken from a couple engines that I saw,
     * which most likely originated from the Aftershock engine.
     * Kudos to them!  What it does is increase/decrease the intensity
     * of the lightmap so that it isn't so dark.  Quake uses hardware to
     * do this, but we will do it in code. 
     * @param im the image to change
     * @param factor how much the image is gamma corrected
     */
    public static void changeGamma(DirectBufferedImage im, float factor) {
        byte pImage[] = im.getBackingStore();
		int psize = (im.getDirectType() == DirectBufferedImage.DIRECT_RGBA) ? 4	: 3;

		byte gtable[] = new byte[256];
		for (int i = 0; i < 256; i++) {
			gtable[i] = (byte) Math.floor(255.0 * Math.pow(i / 255.0, 1.0 / factor) + 0.5);
		}

		// Go through every pixel in the lightmap
		final int size = im.getWidth() * im.getHeight();
		for (int i = 0; i < size; i++) {
			pImage[i * psize + 0] = gtable[pImage[i * psize + 0] & 0xff];
			pImage[i * psize + 1] = gtable[pImage[i * psize + 1] & 0xff];
			pImage[i * psize + 2] = gtable[pImage[i * psize + 2] & 0xff];
		}
    }

	
	
}
