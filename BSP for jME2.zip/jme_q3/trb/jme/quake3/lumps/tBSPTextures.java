package trb.jme.quake3.lumps;

public class tBSPTextures {
    public String name;
    public int surfaceFlags;
    public int contentFlags;


	public static final int SURF_NODAMAGE=		0x1;		// 0000000000000000001	// never give falling damage
	public static final int SURF_SLICK=			0x2;		// 0000000000000000010	// affects game physics
	public static final int SURF_SKY=			0x4;		// 0000000000000000100	// lighting from environment map
	public static final int SURF_LADDER=		0x8;		// 0000000000000001000
	public static final int SURF_NOIMPACT=		0x10;		// 0000000000000010000	// don't make missile explosions
	public static final int SURF_NOMARKS=		0x20;		// 0000000000000100000	// don't leave missile marks
	public static final int SURF_FLESH=			0x40;		// 0000000000001000000	// make flesh sounds and effects
	public static final int SURF_NODRAW=		0x80;		// 0000000000010000000	// don't generate a drawsurface at all
	public static final int SURF_HINT=			0x100;		// 0000000000100000000	// make a primary bsp splitter
	public static final int SURF_SKIP=			0x200;		// 0000000001000000000	// completely ignore, allowing non-closed brushes
	public static final int SURF_NOLIGHTMAP=	0x400;		// 0000000010000000000	// surface doesn't need a lightmap
	public static final int SURF_POINTLIGHT=	0x800;		// 0000000100000000000	// generate lighting info at vertexes
	public static final int SURF_METALSTEPS=	0x1000;		// 0000001000000000000	// clanking footsteps
	public static final int SURF_NOSTEPS=		0x2000;		// 0000010000000000000	// no footstep sounds
	public static final int SURF_NONSOLID=		0x4000;		// 0000100000000000000	// don't collide against curves with this set
	public static final int SURF_LIGHTFILTER=	0x8000;		// 0001000000000000000	// act as a light filter during q3map -light
	public static final int SURF_ALPHASHADOW=	0x10000;	// 0010000000000000000	// do per-pixel light shadow casting in q3map
	public static final int SURF_NODLIGHT=		0x20000;	// 0100000000000000000	// don't dlight even if solid (solid lava, skies)
	public static final int SURF_DUST=			0x40000;	// 1000000000000000000	// leave a dust trail when walking on this surface

											  
											  
	public static final int CONTENTS_SOLID=			0x1;		// 0000000000000000001 0x1		// an eye is never valid in a solid
	public static final int CONTENTS_LAVA=			0x8;		// 0000000000000001000 0x8
	public static final int CONTENTS_SLIME=			0x10;		// 0000000000000010000 0x10
	public static final int CONTENTS_WATER=			0x20;		// 0000000000000100000 0x20		
	public static final int CONTENTS_FOG=			0x40;		// 0000000000001000000 0x40		

	public static final int CONTENTS_NOTTEAM1=		0x80;		// 0000000000010000000 0x80		
	public static final int CONTENTS_NOTTEAM2=		0x100;		// 0000000000100000000 0x100	
	public static final int CONTENTS_NOBOTCLIP=		0x200;		// 0000000001000000000 0x200	

	public static final int CONTENTS_AREAPORTAL=	0x8000;		// 0001000000000000000 0x8000	

	public static final int CONTENTS_PLAYERCLIP=	0x10000;	// 0010000000000000000 0x10000	
	public static final int CONTENTS_MONSTERCLIP=	0x20000;	// 0100000000000000000 0x20000	
//											  bot specific contents types
	public static final int CONTENTS_TELEPORTER=	0x40000;	// 1000000000000000000 0x40000 	
	public static final int CONTENTS_JUMPPAD=		0x80000;
	public static final int CONTENTS_CLUSTERPORTAL=	0x100000;
	public static final int CONTENTS_DONOTENTER=	0x200000;
	public static final int CONTENTS_BOTCLIP=		0x400000;
	public static final int CONTENTS_MOVER=			0x800000;

	public static final int CONTENTS_ORIGIN=		0x1000000;	// removed before bsping an entity

	public static final int CONTENTS_BODY=			0x2000000;	// should never be on a brush, only in game
	public static final int CONTENTS_CORPSE=		0x4000000;
	public static final int CONTENTS_DETAIL=		0x8000000;	// brushes not used for the bsp
	public static final int CONTENTS_STRUCTURAL=	0x10000000;	// brushes used for the bsp
	public static final int CONTENTS_TRANSLUCENT=	0x20000000;	// don't consume surface fragments inside
	public static final int CONTENTS_TRIGGER=		0x40000000;
	public static final int CONTENTS_NODROP=		0x80000000;	// don't leave bodies or items (death fog, lava)
											  
											  
}