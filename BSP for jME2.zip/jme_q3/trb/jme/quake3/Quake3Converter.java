/**
 * Copyright (c) 2003, Xith3D Project Group
 * All rights reserved.
 *
 * Portions based on the Java3D interface, Copyright by Sun Microsystems.
 * Many thanks to the developers of Java3D and Sun Microsystems for their
 * innovation and design.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the 'Xith3D Project Group' nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) A
 * RISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE
 *
 */

package trb.jme.quake3;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.logging.ErrorManager;

import trb.jme.imaging.DirectBufferedImage;
import trb.jme.imaging.TextureLoader;
import trb.jme.quake3.lumps.tBSPFace;
import trb.jme.quake3.lumps.tBSPLeaf;
import trb.jme.quake3.lumps.tBSPTextures;
import trb.jme.quake3.lumps.tBSPVertex;

import com.jme.image.Texture;
import com.jme.light.PointLight;
import com.jme.math.Vector3f;
import com.jme.renderer.ColorRGBA;
import com.jme.renderer.Renderer;
import com.jme.scene.Node;
import com.jme.scene.TexCoords;
import com.jme.scene.TriMesh;
import com.jme.scene.Spatial.CullHint;
import com.jme.scene.state.BlendState;
import com.jme.scene.state.LightState;
import com.jme.scene.state.RenderState;
import com.jme.scene.state.TextureState;
import com.jme.system.DisplaySystem;
import com.jme.util.TextureManager;
import com.jme.util.geom.BufferUtils;

/**
 * Takes the data from a Quake3Loader and converts it into a Java3D scenegraph.  There is
 * obvisouly many ways to do this, so this can be thought of one way to render a quake map.
 * <p/>
 * Originally Coded by David Yazel on Jan 4, 2004 at 6:39:53 PM.
 * Ported to Java3D by Tom-Robert bryntesen on Dec 11, 2005
 */
public class Quake3Converter {

    /** The root of the Q3 level graph */
    private Node root;
    
    /** Loads the Q3 file */
    private Quake3Loader loader;
    
    /** Maps what cluster each leaf is part of */
    private int leafToCluster[];
    
    /** All the planes in the bsp tree described as xyzd */
    private float planes[];
    
    /** For node got the following information: planeIdx, frontNodeIdx and backNodeIdx stored in this array */
    private int nodes[];
    
    /** Holds the what faces is contained in each leaf */
    private BSPLeaf leafs[];
    
    /** All non null faces is represented in this switch with a Shape3D object */
    private BitSwitchNode faceSwitch;
    
    /** One bit for each face in faceSwitch */
    private BitSet faceBitset;
    private int bsLength = 0;
    
    /** An array of BSPLeafs for each cluster */
    private ArrayList[] clusterLeafs;
    
    /** Temp variable used by getCluster(...)*/
    private Vector3f normal = new Vector3f();
    
    /** The last visible cluster */
    private int lastCluster = -2;

    /** We cache unique appearances */
    private Hashtable uniqueAppearances = new Hashtable();
    
    /** Last value of usePVS */
    private boolean lastUsePVS = true;
    private HashMap vizMap = new HashMap();

    Quake3FaceConverter faceConv;

    /**
     * Converts the information stored in the loader into a jME scenegraph
     */
    public Node convert(Quake3Loader loader, DisplaySystem display) {
        this.loader = loader;
        faceConv = new Quake3FaceConverter(loader);

        faceConv.convertLightMaps();
        faceConv.convertTextures();
        
        // add all the faces to faceSwitch and control which are visible using faceBitset.
        bsLength = loader.faces.length;
        faceBitset = new BitSet(bsLength);
        faceSwitch = new BitSwitchNode("", faceBitset);
        setFaceBitset(true);

        // For each face, build a TriMesh object - convert it (
        for (int i = 0; i < bsLength; i++) {
        	// Convert the face to a trimesh if possible and add it to the 
        	TriMesh face = faceConv.convert(loader.faces[i], display);
            if (face != null) {
                faceSwitch.attachChild(face);
            } else {
            	faceSwitch.attachChild(new Node(""));
            }
        }

        // convert the leafs and set up the leaf to cluster mapping
    	clusterLeafs = new ArrayList[loader.visData.numOfClusters];
    	// Array of ClusterID's indexedby leafid
    	leafToCluster = new int[loader.leafs.length];
    	
    	leafs = new BSPLeaf[loader.leafs.length];

    	for (int i = 0; i < loader.leafs.length; i++) {
    		leafs[i] = convertLeaf(loader.leafs[i]);
    		leafToCluster[i] = loader.leafs[i].cluster;
    	}
        
        convertNodes();

        // root only contains the single faceSwitch
        root = new Node("root");
        root.attachChild(faceSwitch);
        
        System.out.println("Total number of triangles: "+faceConv.triangleCnt);
        System.out.println("Total number of unique appearances: "+uniqueAppearances.size());
        return root;
    }
    
    
	/**
     * Sets the value of all the elements of faceBitset.
     * @param value the value to set
     */
    private void setFaceBitset(boolean value) {
    	for (int i=0; i<bsLength; i++) {
    		faceBitset.set(i, value);
    	}
    }

    

    
    /**
	 * Takes all the faces in the leaf and adds them to the cluster
	 */
    private BSPLeaf convertLeaf(tBSPLeaf leaf) {
		if (leaf.numOfLeafFaces == 0) {
			return new BSPLeaf();
		}

		BSPLeaf l = new BSPLeaf();
		l.faces = new int[leaf.numOfLeafFaces];
		for (int i = 0; i < leaf.numOfLeafFaces; i++) {
			l.faces[i] = loader.leafFaces[i + leaf.leafface];
		}
		if (clusterLeafs[leaf.cluster] == null) {
			clusterLeafs[leaf.cluster] = new ArrayList(20);
		}
		clusterLeafs[leaf.cluster].add(l);
		return l;
    }


    /**
	 * converts the nodes and planes for the BSP
	 */
    private void convertNodes() {
		nodes = new int[loader.nodes.length * 3];
		for (int i = 0; i < loader.nodes.length; i++) {
			final int j = i * 3;
			nodes[j + 0] = loader.nodes[i].plane;
			nodes[j + 1] = loader.nodes[i].front;
			nodes[j + 2] = loader.nodes[i].back;
		}

		// now convert the planes
		planes = new float[loader.planes.length * 4];
		for (int i = 0; i < loader.planes.length; i++) {
			final int j = i * 4;
			planes[j + 0] = loader.planes[i].normal.x;
			planes[j + 1] = loader.planes[i].normal.z;
			planes[j + 2] = -loader.planes[i].normal.y;
			planes[j + 3] = loader.planes[i].d * loader.worldScale;
		}
	}


    
    
    // Rendering code 
    
    
    
    
    
    /**
     * Disables geometry that is invisible according to the PVS
     * @param camPos the position of the camera
     * @param usePVS if true the PVS is used to disable hidden geometry, false and everyting is enabled
     */
    public void setVisibility(Vector3f camPos, boolean usePVS) {
    	boolean usePVSChanged = usePVS != lastUsePVS;
    	lastUsePVS = usePVS;
    	
    	if (!usePVS) {
    		//faceBitset.set(0, faceBitset.size() - 1);
    		if (usePVSChanged) {
    			setFaceBitset(true);
    		}
    		return;
    	}
		
    	int camCluster = getCluster(camPos);
		if (lastCluster == camCluster && !usePVSChanged) {
			return;
		}

		System.out.println("new cluster is " + camCluster);
		lastCluster = camCluster;

		setFaceBitset(false);
		int numVis = 0;
		int numFacesVis = 0;
		int numClusters = 0;
		int numLeaves = 0;
        vizMap.clear();
		for (int i = 0; i < loader.visData.numOfClusters; i++) {
			boolean isVisible = isClusterVisible(camCluster, i);
			if (clusterLeafs[i] != null) {
				numClusters++;
				
			}
			if (isVisible && clusterLeafs[i] != null) {
				boolean hasFaces = false;
				for (int j = 0, clSize = clusterLeafs[i].size(); j < clSize; j++) {
					BSPLeaf l = (BSPLeaf)clusterLeafs[i].get(j);
					if (l.faces != null && l.faces.length > 0) {
						numLeaves++;
					}
					for (int k = 0; k < l.faces.length; k++) {
						if (!faceBitset.get(l.faces[k])) {
							faceBitset.set(l.faces[k]);
							Long key = new Long(i << 24
									| loader.faces[l.faces[k]].textureID << 8
									| loader.faces[l.faces[k]].lightmapID);
							if (vizMap.get(key) == null) {
                                vizMap.put(key, key);
							}
							numFacesVis++;
							hasFaces = true;
						}
					}
				}
				if (hasFaces) {
					numVis++;
				}
			}
		}
		//faceSwitch.setChildMask(faceBitset);
		/*
		 System.out.println("num cluster is visible is "+numVis+" out of "+numClusters);
		 System.out.println("num leaves visible is "+numLeaves+" out of "+loader.leafs.length);
		 System.out.println("num faces visible is "+numFacesVis+" out of "+faces.length);
		 System.out.println("num unique shapes is "+map.size());
		 */
	}


    /**
	 * Calculates which cluster the camera position is in.
	 * @param pos the coordinate to check
	 * @return the cluster containing the specified position.
	 */
    private int getCluster( Vector3f pos ) {
        int index = 0;
        while (index >= 0) {
            final int node = index * 3;
            final int planeIndex = nodes[node+0]*4;
            normal.x = planes[planeIndex+0];
            normal.y = planes[planeIndex+1];
            normal.z = planes[planeIndex+2];
            float d = planes[planeIndex+3];

            // Distance from point to a plane
            final float distance = normal.dot(pos) - d;

            if (distance > 0.0001) {
                index = nodes[node+1];
            } else {
                index = nodes[node+2];
            }
        }
        return leafToCluster[-(index + 1)];
    }


    
    /**
     * Checks if testCluster is visible from visCluster.
     * @param visCluster the position of the viewer
     * @param testCluster the clustor to check if is visible from visCluster
     * @return true if cluster is visible
     */
    private boolean isClusterVisible(int visCluster, int testCluster) {
        if ((loader.visData.pBitsets == null) || (visCluster < 0)) {
            return true;
        }

        int i = (visCluster * loader.visData.bytesPerCluster) + (testCluster /8);
        return (loader.visData.pBitsets[i] & (1 << (testCluster & 0x07))) != 0;
    }


    /**
     * Gets the root of the graph containing the level
     */
    public Node getRoot() {
        return root;
    }
    

    /**
     * Helper class and contains a list of faces.
     */
    public class BSPLeaf {
    	/** Faces contained by this leaf */
        int faces[];
    }
}



