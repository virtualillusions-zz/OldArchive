/*
 * Created on 07.apr.2005
 *
 */
package trb.timer;


/**
 *
 */
public class SystemTimer implements TimerInterface {

	public boolean available() {
		return true;
	}
	
	public long getTime() {
		return System.currentTimeMillis();
	}
	
	public long getTimerResolution() {
		return 1000L;		
	}
	
	public void pause() {
		Thread.yield();
	}
	
	
	public String toString() {
		return "SystemTimer";
	}
}
