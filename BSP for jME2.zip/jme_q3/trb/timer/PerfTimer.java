/*
 * Created on 07.apr.2005
 *
 */
package trb.timer;

/**
 *
 */
public class PerfTimer implements TimerInterface {
	
	private sun.misc.Perf perf;
	
	
	public PerfTimer() {
		try {			
			perf = sun.misc.Perf.getPerf();
			// jrockit has the class but not the dll and throws a UnsatisfiedLinkError. Catch all errors to fix this. 
		} catch (Throwable e) {
			perf = null;
		}
	}
	
	
	public boolean available() {
		return (perf != null);
	}
	
	
	public long getTime() {
		return perf.highResCounter();
	}
	
	
	public long getTimerResolution() {
		return perf.highResFrequency();
	}
	
	public void pause() {
		Thread.yield();
	}
	
	
	public String toString() {
		return "PerfTimer";
	}
}
