/*
 * Created on 06.apr.2005
 *
 */
package trb.timer;

/**
 *
 */
public class TRBTimer {
	
	private static TimerInterface timerInterface = null;
	
	
	public static void init() {
		if (timerInterface == null) {
			boolean QPCBroken = false;
			if (new PerfTimer().available()) {
				timerInterface = new PerfTimer();
				
				// if frequency is larger than 200Mhz we assume QPC uses rdtc wich is not reliable
				QPCBroken = timerInterface.getTimerResolution() > (200 * 1000000);
				timerInterface = QPCBroken ? null : timerInterface;
			} 
			
			if (timerInterface == null) {
				// The nano timer uses QPC so avoid it if it's broken
				if (!QPCBroken && new NanoTimer().available()) {
					timerInterface = new NanoTimer();
				} else {
					timerInterface = new SystemTimer();
				}
			}
			
			System.out.println("Timer selected: "+timerInterface);
		}
	}
	
	
	public static long getTime() {
		return timerInterface.getTime();
	}
	
	
	public static long getTimerResolution() {
		return timerInterface.getTimerResolution();
	}
	
	public static void pause() {
		timerInterface.pause();
	}
}
