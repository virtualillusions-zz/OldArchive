/*
 * @(#)DeploySysAction.java	1.1 03/03/08
 *
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

package com.sun.deploy.util;

public interface DeploySysAction {
    public Object execute()
	throws Exception;    
}

