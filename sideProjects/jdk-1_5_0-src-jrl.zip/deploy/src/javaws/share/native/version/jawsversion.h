/*
 * @(#)jawsversion.h	1.4 03/12/19
 * 
 * Copyright 2004 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#define JAVAWS_MAJOR_VERSION _JAVAWS_MAJOR_VER
#define JAVAWS_MINOR_VERSION _JAVAWS_MINOR_VER
#define JAVAWS_MICRO_VERSION _JAVAWS_MICRO_VER
#define JAVAWS_UPDATE_VERSION _JAVAWS_UPDATE_VER
/* JAVAWS_JDK_VERSION should include update versions if it is set */
#define JAVAWS_JDK_VERSION _JAVAWS_JDK_VER
#define JAVAWS_FULL_VERSION _JAVAWS_FULL_VER
#define JAVAWS_CAB_VERSION _JAVAWS_CAB_VER
