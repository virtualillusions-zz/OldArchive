#!BPY
"""
Name: 'Normalise Vertex Group Weights for OGRE'
Blender: 244
Group: 'WeightPaint'
Tooltip: 'Normalise to max.4 groups per vertex, and weights that sum to 1.0'
"""

__author__ = "Stefan Rank"
__version__ = "0.01"
__url__ = ""
__email__ = "strank(AT)strank(DOT)info"
__bpydoc__ = """\
Description:

This Script is to be used only in weight paint mode,
for every vertex in the mesh it reduces the number of groups to 4
(eliminating those with smaller weights)
and them normalises the weights so that they sum to 1.0
This is similar to what Ogre does on importing a skeleton/armature.

"""

#------------------------------------------------------------
# Normalise Vertex Group Weights for OGRE
# (c) 2007 Stefan Rank - strank(AT)strank(DOT)info
#------------------------------------------------------------
# ***** BEGIN GPL LICENSE BLOCK *****
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software Foundation,
# Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# ***** END GPL LICENCE BLOCK *****
#------------------------------------------------------------

import sys
try:
    import Blender
except ImportError:
    sys.exit("Please run this script from within Blender!")

from Blender import Scene, Mesh, Object, Draw, Types, Window
from operator import itemgetter


EPSILON = 0.000001


def bailout(debugerror):
    Draw.PupMenu(debugerror)
    print debugerror


def normaliseweights():
    print 'normalise weights for OGRE called'
    scene = Scene.GetCurrent()
    obj = scene.objects.active
    if not obj or obj.type != 'Mesh':
        return bailout('Error, no active mesh object, aborting.')
    mesh = obj.getData(mesh=True)
    countunassigned = 0
    countremoved = 0
    countnormalised = 0
    # loop through all vertices, maximum 4 weights, normalise sum:
    for index in xrange(len(mesh.verts)):
        vertinfluences = mesh.getVertexInfluences(index)
        numgroups = len(vertinfluences)
        if numgroups < 1:
            countunassigned += 1
            continue
        elif numgroups > 4:
            vertinfluences.sort(key=itemgetter(1))
            for gind in xrange(numgroups - 4):
                name = vertinfluences[gind][0]
                countremoved += 1
                mesh.removeVertsFromGroup(name, [index])
        vertinfluences = mesh.getVertexInfluences(index)
        numgroups = len(vertinfluences)
        assert numgroups < 5
        sumofweights =  sum([infl[1] for infl in vertinfluences])
        if abs(1.0 - sumofweights) > EPSILON:
            countnormalised += 1
            for groupname, weight in vertinfluences:
                if sumofweights < EPSILON: # special case for 0 sum: equal weights
                    newweight = 1.0 / len(vertinfluences)
                else:
                    newweight = weight / sumofweights
                mesh.assignVertsToGroup(groupname, [index], newweight, Mesh.AssignModes.REPLACE)
    finaloutput = "Removed %s weights and normalised weights for %s verts." % \
                  (countremoved, countnormalised)
    print finaloutput
    Draw.PupMenu(finaloutput)
    if countunassigned:
        warning = "WARNING: there were %s vertices without vertex groups" % countunassigned
        print warning
        Draw.PupMenu(warning)


normaliseweights()