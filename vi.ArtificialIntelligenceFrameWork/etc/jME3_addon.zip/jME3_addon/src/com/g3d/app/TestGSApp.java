package com.g3d.app;

import java.net.URL;
import java.util.concurrent.ExecutionException;

import com.g3d.font.BitmapFont;
import com.g3d.font.BitmapText;
import com.g3d.game.state.BaseGameState;
import com.g3d.game.state.GameState;
import com.g3d.game.state.GameStateManager;
import com.g3d.game.state.flyCamGameState;
import com.g3d.material.Material;
import com.g3d.math.Vector3f;
import com.g3d.scene.Geometry;
import com.g3d.scene.shape.Box;
import com.g3d.system.AppSettings;
import com.g3d.texture.Texture;


public class TestGSApp extends GameStateApplication{

	public static void main(String[] args) throws InterruptedException, ExecutionException{
		
		final TestGSApp app = new TestGSApp();
		app.start(true);
		
		GameState TGS = new TestGameState();
        GameStateManager.attachState(TGS);        
      
        flyCamGameState FCGS = new flyCamGameState();
        GameStateManager.attachState(FCGS);        
       // FCGS.setCamSpeed((short) 40);
	}
	
	@Override
	public void start(boolean isState){
		 setSettings(new AppSettings(true));
		// show settings dialog
	        URL iconUrl = SimpleApplication.class.getResource("Monkey.png");
	        SettingsDialog dialog = new SettingsDialog(settings, iconUrl);
	        dialog.showDialog();
	        if (dialog.waitForSelection() == SettingsDialog.CANCEL_SELECTION){
	            // user pressed cancel/exit
	            return;
	        }	        
	        super.start(isState);
	}
	
	@Override
	public void update(){
		super.update();
        renderer.clearBuffers(true, true, true);
        renderManager.render();
	}

/**
 * This is A TestGame State It loads a Box and Text
 * @author Kyle Williams
 */
	static class TestGameState extends BaseGameState{
		
		public TestGameState() {
			super("TestGameState");
			// TODO Auto-generated constructor stub
		}


	    @Override
		public void baseInit() {
				        
		    BitmapFont fnt = GameStateManager.getInstance().getManager().loadFont("angelFont.fnt");

		   BitmapText txt4 = new BitmapText(fnt, false);
		   txt4.setSize(52);
		   txt4.setText("THIS IS A SIMPLE GAMESTATE TEST");
		   txt4.assemble();
		   txt4.setLocalTranslation(40, txt4.getLineHeight()*4, 0);
		   
		   Box b = new Box(Vector3f.ZERO, 1, 1, 1);
	        Geometry geom = new Geometry("Box", b);
	        geom.updateModelBound();

	        Material mat = new Material(GameStateManager.getInstance().getManager(), "plain_texture.j3md");
	        Texture tex = GameStateManager.getInstance().getManager().loadTexture("Monkey.jpg", true, true, false, 16);
	        tex.setMinFilter(Texture.MinFilter.Trilinear);
	        mat.setTexture("m_ColorMap", tex);

	        geom.setMaterial(mat);
	        
	       getRootNode().attachChild(geom);
	       getGuiNode().attachChild(txt4);			
		}

		@Override
		public void cleanup() {
	        System.out.println("Cleanup Being Called");	        
		}

		@Override
		public void render(float tpf) {
		}

		@Override
		public void baseUpdate(float tpf) {
			// TODO Auto-generated method stub
			
		}
		
	}
}
