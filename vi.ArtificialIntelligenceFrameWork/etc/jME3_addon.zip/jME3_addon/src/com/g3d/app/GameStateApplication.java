package com.g3d.app;

import com.g3d.game.state.GameStateManager;


/**
 * The <code>GameStateApplication</code> class represents a possible model of working GameStates
 * this class should be appended to Application.
 * 
 * @author Kyle Williams
 */
public class GameStateApplication extends Application{
	
		protected boolean isGameStates;
	
	public GameStateApplication(){
		super();
		isGameStates=false;
	}
		
	/**Allows the use of GameStates within the Application*/
    public void start(boolean isGameStates){
    	super.start();
    	this.isGameStates=isGameStates;
    	
    	
    }
    	
    /**
     * GameStateManager must be created within the initialize method in order to use all of Applications capabilities
     */
	@Override
	public void initialize(){
    	super.initialize();    	
    	if(isGameStates){
    		// Create the GameStateManager and Initialize the Individual States
            GameStateManager.create(viewPort,manager,renderManager,context,cam,inputManager); 
     	}
	}
    
	/**
	 * This is the Main Update for the Individual GameStates
	 * @param tpf
	 */
    public void GameStateUpdate(float tpf){
    	// Update the GameStates
        GameStateManager.getInstance().update(tpf);
        
       // Render the GameStates
        GameStateManager.getInstance().render(tpf);
    }
    
    
    @Override
    public void update(){
    	super.update();
    	 if(isGameStates){
    		 GameStateUpdate(timer.getTimePerFrame());
    	 }
    }


    
    @Override
    public void destroy(){
    	super.destroy();
    	if(isGameStates){
    		GameStateManager.getInstance().cleanup();
    	}
    }

}