package com.g3d.game.state;

import com.g3d.renderer.queue.RenderQueue.Bucket;
import com.g3d.scene.Node;
import com.g3d.scene.Spatial.CullHint;

/**
 * Creates A similar Setup to SimpleApplication
 * @author Kyle Williams
 *
 */
public abstract class BaseGameState extends GameState{
	
	private Node rootNode = new Node("Root Node");
	private Node guiNode = new Node("Gui Node");
	
    public BaseGameState(String name){
    	this.name=name;
    }
    
    public void gsInit(){		
        guiNode.setQueueBucket(Bucket.Gui);
        guiNode.setCullHint(CullHint.Never);

        GameStateManager.getInstance().getviewPort().attachScene(guiNode);
        GameStateManager.getInstance().getviewPort().attachScene(rootNode);
        baseInit();
    }
    public abstract void baseInit();
     
    
    @Override
	public void update(float tpf) {
        guiNode.updateLogicalState(tpf);
        guiNode.updateGeometricState();	
        rootNode.updateLogicalState(tpf);
        rootNode.updateGeometricState();
        baseUpdate(tpf);
	}
    
    public abstract void baseUpdate(float tpf);
    
    /**
     * Returns Root Node
     * @return rootNode
     */
    public Node getRootNode(){
    	return rootNode;
    }
    /**
     * Returns GUI Node
     * @return guiNode
     */
    public Node getGuiNode(){
    	return guiNode;
    }

	
}
