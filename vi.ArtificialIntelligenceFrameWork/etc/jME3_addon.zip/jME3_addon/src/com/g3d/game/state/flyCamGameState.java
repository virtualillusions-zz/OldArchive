package com.g3d.game.state;

import java.util.logging.Logger;

import com.g3d.input.FlyByCamera;
import com.g3d.input.InputManager;
import com.g3d.input.KeyInput;
import com.g3d.input.binding.BindingListener;
import com.g3d.math.Quaternion;
import com.g3d.math.Vector3f;
import com.g3d.renderer.Camera;

/**
 * Enables the user to transverse the game by moving the Camera
 * @author Kyle Williams
 *
 */
public class flyCamGameState extends GameState{
        private FlyByCamera flyCam;
	@Override
	protected void gsInit() {	
		this.name="flyCamGameState";
		final Camera cam=GameStateManager.getInstance().getCamera();
		
		InputManager inputManager=GameStateManager.getInstance().getInputManager();
		
		if (inputManager != null){
            flyCam = new FlyByCamera(cam);
            flyCam.setMoveSpeed(1f);
            flyCam.registerWithDispatcher(inputManager);
        
            inputManager.registerKeyBinding("SIMPLEAPP_Exit", KeyInput.KEY_ESCAPE);
            inputManager.registerKeyBinding("SIMPLEAPP_CameraPos", KeyInput.KEY_C);
            inputManager.addTriggerListener(new BindingListener() {
                public void onBinding(String binding, float value) {
                    if (binding.equals("SIMPLEAPP_Exit")){
                    	Logger.getLogger(flyCamGameState.class.getName()).
                    							fine("Closing application: "+getClass().getName());
                    	GameStateManager.getInstance().getContext().destroy();
                    }else if (binding.equals("SIMPLEAPP_CameraPos")){
                        if (cam != null){
                            Vector3f loc = cam.getLocation();
                            Quaternion rot = cam.getRotation();
                            System.out.println("Camera Position: ("+
                                    loc.x+", "+loc.y+", "+loc.z+")");
                            System.out.println("Camera Position: "+rot);
                        }
                    }
                }
            });
        }
        System.out.println("Done");
	}
	
	public void setCamSpeed(short Speed){
		flyCam.setMoveSpeed(Speed);
	}

	@Override
	public void render(float tpf) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(float tpf) {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void cleanup() {
		// TODO Auto-generated method stub
		
	}

}
