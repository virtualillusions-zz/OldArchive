package com.g3d.game.state;

import java.util.ArrayList;
import java.util.logging.Logger;


import com.g3d.asset.AssetManager;
import com.g3d.input.InputManager;
import com.g3d.renderer.Camera;
import com.g3d.renderer.RenderManager;
import com.g3d.renderer.ViewPort;
import com.g3d.system.G3DContext;

/**
 * GameStateManager is nothing more than a singleton 
 * GameStateNode. Use this to Attach all Game States to
 * 
 * @see GameStateNode
 * @see GameState
 * 
 * @author Kyle Williams
 */
public class GameStateManager extends GameStateNode<GameState> {
    private static final Logger logger = Logger
            .getLogger(GameStateManager.class.getName());
	
	/** The singleton. */
	private static GameStateManager instance;
	
	private ViewPort viewPort;
	private AssetManager manager;
	private RenderManager renderManager;
	private G3DContext context;
	private Camera cam;
	private InputManager inputManager;
	
	/**
	 * Private constructor.
	 */
	private GameStateManager(ViewPort viewPort, AssetManager manager, RenderManager renderManager, G3DContext context, Camera cam, InputManager inputManager) {
		super("Game State Manager");
		this.viewPort=viewPort;
		this.manager=manager;
		this.renderManager=renderManager;
		this.context=context;
		this.cam=cam;
		this.inputManager=inputManager;
	}
	
	/**
	 * Creates a new <code>GameStateManager</code>.
	 * @param inputManager 
	 * @param cam 
	 * @param context 
	 * @param renderManager 
	 * 
	 * @return If this is the first time create() is called, a new instance
	 * will be created and returned. Otherwise one should use getInstance()
	 * instead.
	 */
	public static void create(ViewPort viewPort, AssetManager manager, RenderManager renderManager, G3DContext context, Camera cam, InputManager inputManager) {
		if (instance == null) {
			instance = new GameStateManager(viewPort,manager,renderManager,context,cam,inputManager);
			getInstance().gsInit();
			logger.info("Created GameStateManager and initialized GameStates");
		}		
	}
	
	/**
	 * Returns the singleton instance of this class. <b>Note that create() has
	 * to have been called before this.</b>
	 * 
	 * @return The singleton.
	 */
	public static GameStateManager getInstance() {
		if (instance == null) {
   		 		// init has not been called yet.
				logger.entering(GameStateManager.class.getName(), "get()");
				logger.severe("ALERT, call init first!!");
		}
		return instance; 		
	}
	
	public ViewPort getviewPort(){
		return viewPort;
	}

	public AssetManager getManager() {
		return manager;
	}
	
	public RenderManager getRenderManager() {
		return renderManager;
	}
	public G3DContext getContext() {
		return context;
	}
	public Camera getCamera() {
		return cam;
	}
	public InputManager getInputManager() {
		return inputManager;
	}

	@Override
	protected void gsInit() {
		setActive(true);
		logger.info("Begin GameState Initialization");
		for(GameState state : tempList){
			getInstance().attachChild(state);
			state.setActive(true);
			state.gsInit();
			logger.info("THE GameState "+state.name+" Has Been Initiated Correctly");
		}
		tempList.clear();
		logger.info("All GameStates Have Been Initalized");
	}

	static private ArrayList<GameState> tempList = new ArrayList<GameState>();
	/**
	 * Used initially Attaching GameStates.
	 * */
	public static void attachState(GameState GS) {
		tempList.add(GS);
	}
	
	
}

