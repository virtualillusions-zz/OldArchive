package util.State;

import com.g3d.renderer.RenderManager;

public abstract class AppState{

	/** The name of this GameState. */
	protected String name;
	
	/** Flags whether or not this GameState should be processed. */
	protected boolean active; 
	
	/** GameState's parent, or null if it has none. */
	protected AppStateDirector parent;		
	
	/**
	 * Get the name of the State
	 */
	public String getName(){return name;}
	
	/**
	 * used to check if the state is active or inactive 
	 * @return is Active
	 */
	public boolean isActive(){return active;}
	
	/**
	 * Used to set if the GameState is active or inactive
	 * @param active
	 */
	public void setActive(boolean active){this.active=active;}
	
	/**
	 * Sets the parent of this node. <b>The user should never touch this method,
	 * instead use the attachChild method of the wanted parent.</b>
	 * 
	 * @param parent The parent of this GameState.
	 */
	public void setParent(AppStateDirector parent) {
		this.parent = parent;
	}
	
	/**
	 * Retrieves the parent of this GameState. If the parent is null, this is
	 * the root node.
	 * 
	 * @return The parent of this node.
	 */
	public AppStateDirector getParent() {
		return parent;
	}
	
	/**
	 * Gets called every successive frame
	 * @param tpf The Elapsed Time since the Last Frame
	 */
	public abstract void update(float tpf);
	
	/**
	 * Used to Directly Access the Render Manager
	 * @param rm
	 */
	public abstract void render(RenderManager rm);		
	/**
	 * used to perform all last minute actions before the applocation closes
	 */
	public abstract void cleanup();
	
}	
