package com.jmex.simplephysics;

import java.util.Set;

//import com.jme.scene.batch.TriangleBatch;
import com.jme.scene.TriMesh;

/**
 * <code>CollisionResult</code> stores the result of a collision.
 * 
 * @author Lucas Goraieb
 */
public class CollisionResult {

	private Set<Integer> triangles;
	
	private TriMesh batch;
	
	private StaticCollider collider;
	
	public CollisionResult(StaticCollider collider, TriMesh batch, Set<Integer> triangles) {
		this.collider = collider;
		this.batch = batch;
		this.triangles = triangles;
	}

	public TriMesh getBatch() {
		return batch;
	}

	public Set<Integer> getTriangles() {
		return triangles;
	}

	public StaticCollider getCollider() {
		return collider;
	}
	
}
